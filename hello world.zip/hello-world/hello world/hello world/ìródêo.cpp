#include <iostream>

using namespace std;

int main()
{
	cout << "hello world";
	system("pause");
	return 0;
}